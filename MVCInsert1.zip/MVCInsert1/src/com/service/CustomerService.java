package com.service;

import java.sql.SQLException;

import com.bean.Customer;
import com.dao.CustomerDao;

public class CustomerService {

	CustomerDao cDao = new CustomerDao();
	public Integer addCustomer(Customer customer) throws ClassNotFoundException, SQLException
	{	
		return cDao.addCustomer(customer);
	}
}
