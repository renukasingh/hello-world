package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import com.service.CustomerService;
import com.util.DateUtil;

public class CustomerController extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	{
		
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		CustomerService service = new CustomerService();
		String source = req.getParameter("source");
		if(source.equals("addCustomer"))
		{
			Customer customer = new Customer();
			customer.setFirstName(req.getParameter("firstName"));
			customer.setLastName(req.getParameter("lastName"));
			customer.setDob(DateUtil.convertStringToDate(req.getParameter("dob"),"dd/mm/yyyy"));
			customer.setGender(req.getParameter("gender"));
			customer.setCity(req.getParameter("city"));
			customer.setCountry(req.getParameter("country"));
			customer.setEmail(req.getParameter("email"));
			customer.setAnnualSalary(Double.parseDouble(req.getParameter("salary")));
			
			System.out.println("Customer details:\n" + customer);
			
			try{
				Integer customerId = service.addCustomer(customer);
				if(customerId!=null)
				{
					req.setAttribute("customerId", customerId);
				}
				RequestDispatcher rd = req.getRequestDispatcher("addCustomer.jsp");
				rd.forward(req, res);
			}catch(ClassNotFoundException | SQLException e){
				e.printStackTrace();
			}
		}
	}
}
