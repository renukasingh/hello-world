package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bean.Customer;
import com.util.DatabaseUtil;

public class CustomerDao {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	Statement st = null;

	public Integer addCustomer(Customer cust) throws ClassNotFoundException, SQLException
	{
		String query = null;
		Integer customerId = null;
		con = DatabaseUtil.getConnection();
		
		ps = con.prepareStatement("INSERT INTO Customer_1128944(CUSTOMERID ,FIRSTNAME,LASTNAME,DOB,GENDER,CITY,COUNTRY,EMAIL,ANNUAL_SALARY) VALUES (seqCust.nextVal,?,?,?,?,?,?,?,?)");
		
		ps.setString(1, cust.getFirstName());
		ps.setString(2, cust.getLastName());
		ps.setDate(3, new java.sql.Date(cust.getDob().getTime()));
		ps.setString(4, cust.getGender());
		ps.setString(5, cust.getCity());
		ps.setString(6, cust.getCountry());
		ps.setString(7, cust.getEmail());
		ps.setDouble (8, cust.getAnnualSalary());
		
		int rowStatus = ps.executeUpdate();
		
		query = "SELECT MAX(CUSTOMERID) FROM Customer_1128944";
		st = con.createStatement();
		rs = st.executeQuery(query);
		while(rs.next())
		{
			customerId = (Integer)rs.getInt(1);
			System.out.println("customer id : " + customerId);
		}
		return customerId;
	}
}
