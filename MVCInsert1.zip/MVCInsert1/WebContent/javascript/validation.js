function chkFirstName()
{
var firstName  = document.customerForm.firstName.value;
if(firstName==null || firstName.length<=0)
{
	alert("Please enter first name");
	document.customerForm.firstName.focus();
	return false;
}
return true;
}

function chkLastName()
{
var lastName  = document.customerForm.lastName.value;
if(lastName==null || lastName.length<=0)
{
	alert("Please enter last name");
	document.customerForm.lastName.focus();
	return false;
}
return true;
}

function chkDateOfBirth()
{
var dob  = document.customerForm.dob.value;
if(dob==null || dob.length<=0)
{
	alert("Please enter dob");
	document.customerForm.dob.focus();
	return false;
}
return true;
}

function chkCity()
{
var city = document.customerForm.city.value;
var letters = /^[A-Za-z]+$/;
if(city!=null || city.length>0)
{
	if(city.match(letters))
		return true;
	else
		{
		alert("only alphabets");
		document.customerForm.city.focus();
		return false;
		}
}
else
	{
	alert("please enter city");
	document.customerForm.city.focus();
	return false;
	}
}

function chkEmail()
{
var email = document.customerForm.email.value;
var letters = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(email!=null || email.length>0)
{
	if(letters.test(email))
		return true;
	else
		{
		alert("invalid email");
		document.customerForm.email.focus();
		return false;
		}
}
else
	{
	alert("please enter email");
	document.customerForm.email.focus();
	return false;
	}
}

function checkSalary()
{
var salary = document.customerForm.salary.value;
var letters = /^[0-9]+$/;
if(salary!=null || salary.length>0)
{
	if(letters.test(email))
		return true;
	else
		{
		alert("numbers only");
		document.customerForm.salary.focus();
		return false;
		}
}
else
	{
	alert("please enter salary");
	document.customerForm.salary.focus();
	return false;
	}
}
