package com.controller;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.bean.Customer;
import com.tcs.service.CustomerService;



public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Customer customer ;

    
    public CustomerController() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//Customer customer ;
	PrintWriter out=response.getWriter();
	CustomerService service=new CustomerService();
	// Customer customer=null;
String source=request.getParameter("searchParam");






if(source.equals("customerId")){
	
String customerId=request.getParameter("searchValue");
 try {
	customer=service.searchCustomerById(Integer.parseInt(customerId));
} catch (NumberFormatException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

if(customer!=null){
	out.println("<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" >");
		out.println("<tr><td> customer Id</td><td>"+customer.getCustomerId()+"</td></tr>"
				
				+"<tr><td> firstName</td><td>"+customer.getFirstName()+"</td></tr>"
				+"<tr><td> lastName</td><td>"+customer.getLastName()+"</td></tr>"
				+"<tr><td> contact</td><td>"+customer.getContact()+"</td></tr>"
				+"<tr><td> gender </td><td>"+customer.getGender()+"</td></tr>"
				+"<tr><td>married</td><td>"+customer.getMarried()+"</td></tr>"
				+"<tr><td> city</td><td>"+customer.getCity()+"</td></tr>");
		out.println("</table>");
}
		else{
			out.println("no such customer exist for id  "+customerId);
			
		}
		 
	
	
}

	



if(source.equals("city")){
ArrayList<Customer> custList=null;
	
	
	String city=request.getParameter("searchValue");
 try {
	 custList=service.searchCustomerByCity(city);
} catch (NumberFormatException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

 if(custList!=null || !custList.isEmpty()){
		
		out.println("<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" >");
		int i=1;	
		for(Customer customer:custList){
		out.println(
				"<tr><b><td colspan=\"2\">CUSTOMER"+(i++)+"</td></b></tr>"
				+"<tr><td> customer Id</td><td>"+customer.getCustomerId()+"</td></tr>"
				
					+"<tr><td> firstName</td><td>"+customer.getFirstName()+"</td></tr>"
					+"<tr><td> lastName</td><td>"+customer.getLastName()+"</td></tr>"
					+"<tr><td> contact</td><td>"+customer.getContact()+"</td></tr>"
					+"<tr><td> gender </td><td>"+customer.getGender()+"</td></tr>"
					+"<tr><td>married</td><td>"+customer.getMarried()+"</td></tr>"
					+"<tr><td> city</td><td>"+customer.getCity()+"</td></tr>");
		}
		
		out.println("</table>");

		
		}
		else{
			out.println("no such customer exist with this city "+city);
			
		}
		 
	
	
	


}
if(source.equals("hobby")){
	 ArrayList<Customer> custList=null;
	
	
	String hobby=request.getParameter("searchValue");
	 try {
 custList=service.searchCustomerByHobby(hobby);
	} catch (NumberFormatException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	if(custList!=null){
		
		out.println("<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" >");
		int i=1;	
		for(Customer customer:custList){
		out.println(
				"<tr><b><td colspan=\"2\">CUSTOMER"+(i++)+"</td></b></tr>"
				+"<tr><td> customer Id</td><td>"+customer.getCustomerId()+"</td></tr>"
				
					+"<tr><td> firstName</td><td>"+customer.getFirstName()+"</td></tr>"
					+"<tr><td> lastName</td><td>"+customer.getLastName()+"</td></tr>"
					+"<tr><td> contact</td><td>"+customer.getContact()+"</td></tr>"
					+"<tr><td> gender </td><td>"+customer.getGender()+"</td></tr>"
					+"<tr><td>married</td><td>"+customer.getMarried()+"</td></tr>"
					+"<tr><td> city</td><td>"+customer.getCity()+"</td></tr>");
			

		}
		out.println("</table>");
		}
			else{
				out.println("no such customer exist with this hobby "+hobby);
				
			}
			 
		
		
	


}
	
	
	
	}

}
