package com.tcs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.bean.Customer;
import com.tcs.bean.Hobby;
import com.tcs.util.DbUtil;

public class CustomerDAOImpl  implements CustomerDAO {
	ResultSet rs=null;
	ArrayList<Hobby> hobby;

	@Override
	public Customer searchCustomerById(int customerId) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getConnection();
		Customer customer=null;
		PreparedStatement pst=con.prepareStatement("select * from Customer where customerid= ?");
		pst.setInt(1, customerId);
rs=pst.executeQuery();		
	while(rs.next()){
		customer=new  Customer();
		
		customer.setFirstName(rs.getString("firstname"));
		customer.setLastName(rs.getString("lastName"));
		customer.setCity(rs.getString("city"));
		customer.setContact(rs.getString("contact"));
		customer.setGender(rs.getString("gender"));
		
		
		//customer.setHobbyList(hobbyList)
		
		
		
	}	
	DbUtil.closeConnection(con);
	rs.close();
	pst.close();
	return customer;
	
	

	}
	
	public ArrayList<Customer>  searchCustomerByCity(String city) throws ClassNotFoundException, SQLException {
		ArrayList<Customer> custList=new ArrayList<>();
		
		
		Connection con=DbUtil.getConnection();
		Customer customer=new Customer();
		PreparedStatement pst=con.prepareStatement("select * from Customer where city= ?");
		pst.setString(1, city);
rs=pst.executeQuery();		
	while(rs.next()){
		
		customer.setFirstName(rs.getString("firstname"));
		customer.setLastName(rs.getString("lastName"));
		customer.setCity(rs.getString("city"));
		customer.setContact(rs.getString("contact"));
		customer.setGender(rs.getString("gender"));
		custList.add(customer);
		
		
		//customer.setHobbyList(hobbyList)
		
		
		
	}	
	DbUtil.closeConnection(con);
	rs.close();
	pst.close();
	return custList;
	
	

	}

	
	
	
	
	public ArrayList<Customer> searchCustomerByHobby(String hobby) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getConnection();
		ArrayList<Customer> custList=new ArrayList<>();
		Customer customer=new Customer();
		PreparedStatement pst=con.prepareStatement("select * from Customer join hobby where hobby= ?");
		pst.setString(1, hobby);
rs=pst.executeQuery();		
	while(rs.next()){
		
		customer.setFirstName(rs.getString("firstname"));
		customer.setLastName(rs.getString("lastName"));
		customer.setCity(rs.getString("city"));
		customer.setContact(rs.getString("contact"));
		customer.setGender(rs.getString("gender"));
		custList.add(customer);
		
		
		//customer.setHobbyList(hobbyList)
		
		
		
	}	
	DbUtil.closeConnection(con);
	rs.close();
	pst.close();
	return custList;
	
	

	}

	
	
	
	
	
}
