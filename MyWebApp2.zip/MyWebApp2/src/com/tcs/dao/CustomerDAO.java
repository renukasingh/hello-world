package com.tcs.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.bean.Customer;

public interface CustomerDAO  {
	public Customer searchCustomerById(int customerId ) throws ClassNotFoundException,SQLException;
	public ArrayList<Customer> searchCustomerByCity(String city) throws ClassNotFoundException,SQLException;
	public ArrayList<Customer> searchCustomerByHobby(String hobby ) throws ClassNotFoundException,SQLException;


}
