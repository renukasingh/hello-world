package com.tcs.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	
	static String url="jdbc:oracle:thin:@172.25.192.82:1521:javaaodb";
	static String user="HJA40ORAUSER2D";
	static String pwd="tcshyd";
	
	
	public static Connection getConnection() throws SQLException, ClassNotFoundException{
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
			
			return DriverManager.getConnection(url, user, pwd);
			
			
			
			
		
		
		
		
	}
	
	public static void closeConnection(Connection con) throws SQLException{
		con.close();
		
		
	}
	
	
	

}
