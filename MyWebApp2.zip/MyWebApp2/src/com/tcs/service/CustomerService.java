package com.tcs.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.bean.Customer;
import com.tcs.dao.CustomerDAO;
import com.tcs.dao.CustomerDAOImpl;

public class CustomerService {
	
	public Customer searchCustomerById(int customerId ) throws ClassNotFoundException, SQLException{
		CustomerDAO cdao=new CustomerDAOImpl();
		return cdao.searchCustomerById(customerId);
		
		
		
	}
	
	public ArrayList<Customer> searchCustomerByCity(String city) throws ClassNotFoundException, SQLException{
		CustomerDAO cdao=new CustomerDAOImpl();
		return cdao.searchCustomerByCity(city);
		
		
		
	}
	
	public ArrayList<Customer> searchCustomerByHobby(String hobby ) throws ClassNotFoundException, SQLException{
		CustomerDAO cdao=new CustomerDAOImpl();
		return cdao.searchCustomerByHobby(hobby);
		
		
		
	}
	

}
