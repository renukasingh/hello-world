function chkFirstName()
{
	var firstname = document.form.firstname.value;
	if(firstname == null || firstname.length <= 0)
	{
		alert("Please enter first name");
		document.form.firstname.focus();
		return false;
	}
	return true;
}
function chkLastName()
{
	var lastname = document.form.lastname.value;
	if(lastname == null || lastname.length <= 0)
	{
		alert("Please enter the last name");
		document.form.lastname.focus();
		return false;
	}
	return true;
}
function chkDateOfBirth()
{
	var dob = document.form.lastname.value;
	if(dob == null || dob.length <= 0)
	{
		alert("Please enter the date of birth");
		document.form.dob.focus();
		return false;
	}
	return true;
}

function chkCity()
{
	var city = document.form.city.value;
	var letters = /^[A-Za-z]+$/;
	if(city!=null && city.length > 0)
	{
		if(city.match(letters))
			return true;
		else {
			alert("please use only alphabets ");
			document.form.city.focus();
			return false;
		}
	}
	else {
		alert("please enter the city");
		document.form.city.focus();
		return false;
	}
}

