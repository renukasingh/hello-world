package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

	private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String USER = "HJA40ORAUSER5D";
	private static final String PWD = "tcshyd";
	private static final String URL = "jdbc:oracle:thin:@172.25.192.82:1521:javaaodb";
	
	public static Connection getconnection() throws ClassNotFoundException
	{
		Connection conn = null;
		try
		{
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USER, PWD);
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void closeConnection(Connection conn)
	{
	if (conn != null)	
	try{
		conn.close();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}
}
