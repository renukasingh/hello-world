package com.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public static Date convertStringToDate(String inStringDate, String format)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		Date date = null;
		try{
			System.out.println("Date in string " +inStringDate);
			date = formatter.parse(inStringDate);
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		return date;}

}
