package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import com.service.CustomerService;
import com.util.DateUtil;

public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CustomerController() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerService cs = new CustomerService();
		String source = request.getParameter("source");
		if(source.equals("addCustomer"))
		{
			Customer cust = new Customer();
			cust.setFirstname(request.getParameter("firstname"));
			cust.setLastname(request.getParameter("lastname"));
			cust.setDob(DateUtil.convertStringToDate(request.getParameter("dob"), "dd/mm/yyyy" ));
			cust.setCity(request.getParameter("city"));
			cust.setCountry(request.getParameter("country"));
			cust.setGender(request.getParameter("gender"));
			
			System.out.println("Customer: " +cust);
			
			try{
			Integer customerid = cs.addCustomer(cust);
			if(customerid != null )
			{
				request.setAttribute("customerId", customerid);
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("addCustomer.jsp");
			rd.forward(request, response);
				
			}
			catch(SQLException | ClassNotFoundException e)
			{
				e.printStackTrace();
			}
		}
	}

}
