package com.service;

import java.sql.SQLException;

import com.bean.Customer;
import com.dao.CustomerDAO;

public class CustomerService {
	
	CustomerDAO cdao = new CustomerDAO();
	 public Integer addCustomer(Customer cust) throws SQLException, ClassNotFoundException
	 {
		 return cdao.addCustomer(cust);
	 }

}
