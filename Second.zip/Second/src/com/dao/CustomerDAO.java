package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bean.Customer;
import com.util.DatabaseUtil;

public class CustomerDAO {
 Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	Statement stmt = null;
	
	public Integer addCustomer(Customer cust) throws SQLException,ClassNotFoundException
	{
		String query = null;
		Integer customerid = null;
		conn = DatabaseUtil.getconnection();
		 ps = conn.prepareStatement("insert into customer_1 (customerid,firstname, lastname, dob, gender, city, country ) values" +
		 		"(custSeq.nextval,?,?,?,?,?,?)");
		 
		 ps.setString(1,cust.getFirstname());
		 ps.setString(2, cust.getLastname());
		 ps.setDate(3, new java.sql.Date(cust.getDob().getTime()));
		 ps.setString(4, cust.getGender());
		 ps.setString(5, cust.getCity());
		 ps.setString(6, cust.getCountry());
		 
		 int rowstatus = ps.executeUpdate();
		 
		 query = "Select max(customerid) from customer_1";
		 stmt = conn.createStatement();
		 rs = stmt.executeQuery(query);
	 while(rs.next())
	 {
		 customerid = (Integer)rs.getInt(1);
		 System.out.println("CustomerID: " +customerid);
	 }
	 return customerid;
	}
}
