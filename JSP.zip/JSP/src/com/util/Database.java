package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Database {
	
	String url="jdbc:oracle:thin:@172.25.192.82:1521:javaaodb";
	String uname="HJA40ORAUSER6D";
	String pwd="tcshyd";

	public  Connection connect(){
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
				con=DriverManager.getConnection(url,uname,pwd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
		
	}
	
	public static void cleanup(Connection con)
	{
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
