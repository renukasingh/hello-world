package com.util;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateUtil {
public static Date convert(String date,String format)
	
	{
	SimpleDateFormat sdf=new  SimpleDateFormat(format);
	Date dat=null;
	try {
		sdf.parse(date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return dat;
}
}
