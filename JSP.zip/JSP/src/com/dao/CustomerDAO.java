package com.dao;

import java.sql.*;

import com.bean.Customer;
import com.util.Database;



public class CustomerDAO {
	
	public Integer addCustomer(Customer c) throws SQLException , ClassNotFoundException
		{PreparedStatement ps=null;
		Statement st;
		Connection con;
		String sql=null;
		Integer id=null;
		Database db=new Database();
		con=db.connect();
		
		sql="insert into cust121(id,fname,lname,dob,gender,city,email,country,annual_salary) values(seq121.nextval,?,?,?,?,?,?,?,?) ";
		ps=con.prepareStatement(sql);
		ps.setString(1, c.getFname());
		ps.setString(2,c.getLname());
		ps.setDate(3,new java.sql.Date(c.getDob().getTime()));
		ps.setString(4,c.getGender());
		ps.setString(5, c.getCity());
		
		ps.setString(6, c.getEmail());
		ps.setString(7, c.getCountry());
		ps.setDouble(8,c.getAnnual_salary());
		
		int r=ps.executeUpdate();
		
		sql="select max(id) from cust121";
		st=con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		
		while(rs.next())
		{
			id=(Integer)rs.getInt(1);
			System.out.println("id is"+id);
			
		}
		
		
		return	id;
		}

	}

