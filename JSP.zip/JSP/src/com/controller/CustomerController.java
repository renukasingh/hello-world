package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.service.*;

import com.bean.Customer;

import com.util.DateUtil;

@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public CustomerController() {

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{	CustomerService cs=new CustomerService();
	String source=req.getParameter("source");

	if(source.equals("addCustomer"))
	{Customer c=new Customer();
	c.setFname(req.getParameter("fname"));
	c.setLname(req.getParameter("lname"));
	c.setDob(DateUtil.convert(req.getParameter("dob"), "dd/mm/yyyy"));
	c.setEmail(req.getParameter("email"));
	c.setGender(req.getParameter("gender"));
	c.setCountry(req.getParameter("sel"));
	c.setCity(req.getParameter("city"));
	c.setAnnual_salary(Double.parseDouble(req.getParameter("annual_salary")));
	
	try
	{
	Integer id=cs.addCustomer(c);
	if(id!=null)
	{
		req.setAttribute("id", id);
		RequestDispatcher rd=req.getRequestDispatcher("addCustomer.jsp");
		rd.forward(req, res);
	}
	}
	catch(ClassNotFoundException|SQLException e)
	{e.printStackTrace();}
		
		
	}
	}
	}

	
