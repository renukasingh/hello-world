function chkFname()
{
var fname=document.customerForm.fname.value;
if(fname==null||fname.length<=0)
	{alert("enter fname");
	document.customerForm.fname.focus();
	return false;
	}
return true;

}

function chkLname()
{
var lname=document.customerForm.lname.value;
if(lname==null||lname.length<=0)
	{alert("ente lanme");
	document.customerForm.lname.focus();
	return false;}
return true;
}

function chkDob()
{
var dob=document.customerForm.dob.value;
if( dob==null|| dob.length<=0)
	{alert("enter dob");
	document.customerForm.dob.focus();
	return false;}
return true;
}

function chkCity()
{
var city=document.customerForm.city.value;
var letter=/^[A-Za-z]+$/;

if(city!=null||city.length>0)
	{if(city.match(letter))
		{return true;}
	
	else
		{alert("alphabetys only");
		document.customerForm.city.focus();}
	}
	
	else	
		{alert ("enter city");
	document.customerForm.city.focus();
	return false;}

}

function chkCountry()
{
	if(sel!="")
		{
		return true;
		}
	else
		{
		alert("select country");
		document.customerForm.country.focus();
		return false;
		
		}
}



function chkSalary()
{
	var sal= document.customerForm.salary.value;
var num=/^[0-9]+$/	;

if(sal!=null||sal.length>0)
{if(!num.test(sal))
	{alert("neter number");
	document.customerForm.country.focus();
	return false;
	}
else
	{return true;}
}
else
	{alert("neter sal");}


}

