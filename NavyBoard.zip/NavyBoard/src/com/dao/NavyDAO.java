package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.BaseCamp;
import com.bean.Officer;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
import com.util.DBTransaction;

public class NavyDAO {

	public int addOfficer(Officer o)
	{
		int i = 0;
		Connection conn = DBTransaction.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement("Insert into Officers_table values(seq.val,?,?,?,?)");
			ps.setString(1, o.getOfficerName());
			ps.setString(2, o.getOfficerRank());
			ps.setDouble(3, o.getSalary());
			ps.setInt(4, o.getBaseCampId());
			ps.executeUpdate();
			
		
			String query = "Select officer id from officers_table where id = ?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, o.getBaseCampId());
			ResultSet rs = ps.executeQuery(query);
			 while(rs.next())
			 {
				 i = rs.getInt(1);
				 return i;
			 }
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return i;
	}	
	
	public ArrayList<String> getOfficersNameSortedBySal() 
	{
		ArrayList<String> oal = new ArrayList<String>();
		Connection conn = DBTransaction.getConnection();
		PreparedStatement ps = null;
		String query = "Select officer_name from officers_table ordered by officer_sal";
		try {
			ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				oal.add(rs.getString(1));
				return oal;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return null;
	}
	
	public ArrayList<String> getOfficersNameForBaseCampLoc(String b)
	{
		ArrayList<String> oal = new ArrayList<String>();
		Connection conn = DBTransaction.getConnection();
		PreparedStatement ps = null;
		String query = "Select o.officer_name from officers_table o, Base_camp b where b.base_camp_loc =? and o.base_camp_id = b.base_camp_id ";
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, b );
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				oal.add(rs.getString(1));
				return oal;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return null;	
	}
	
	public double getOfficersTotalSalOnBaseCamp(int bid) 
	{
		double sal = 0;
		Connection conn = DBTransaction.getConnection();
		PreparedStatement ps = null;
		String query = "Select sum(o.Officer_sal)as total_salary from officers_table o, Base_camp b where b.base_camp_id =? and o.base_camp_id = b.base_camp_id ";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, bid);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				sal = rs.getDouble(1);
				return sal;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public int updateBaseCampDetails(BaseCamp base, int id)
	{
		int i =0;
		Connection conn = DBTransaction.getConnection();
		PreparedStatement ps = null;
		String query = "update table base_camp set base_camp_name = ? where base_camp_id =?";
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, base.getBaseCampName());
			ps.setInt(2, id);
			i = ps.executeUpdate();
			return i;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
}
