package com.bean;

public class BaseCamp {
	
	private int baseCampId;
	private String baseCampName;
	private String baseCampLocation;
	public int getBaseCampId() {
		return baseCampId;
	}
	public void setBaseCampId(int baseCampId) {
		this.baseCampId = baseCampId;
	}
	public String getBaseCampName() {
		return baseCampName;
	}
	public void setBaseCampName(String baseCampName) {
		this.baseCampName = baseCampName;
	}
	public String getBaseCampLocation() {
		return baseCampLocation;
	}
	public void setBaseCampLocation(String baseCampLocation) {
		this.baseCampLocation = baseCampLocation;
	}
	
	

}
