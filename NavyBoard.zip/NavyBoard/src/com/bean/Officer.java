package com.bean;

public class Officer {

	private int officerNo;
	private String officerName;
	private String officerRank;
	private double salary;
	private int baseCampId;
	public int getOfficerNo() {
		return officerNo;
	}
	public void setOfficerNo(int officerNo) {
		this.officerNo = officerNo;
	}
	public String getOfficerName() {
		return officerName;
	}
	public void setOfficerName(String officerName) {
		this.officerName = officerName;
	}
	public String getOfficerRank() {
		return officerRank;
	}
	public void setOfficerRank(String officerRank) {
		this.officerRank = officerRank;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getBaseCampId() {
		return baseCampId;
	}
	public void setBaseCampId(int baseCampId) {
		this.baseCampId = baseCampId;
	}
	
	
	
}
