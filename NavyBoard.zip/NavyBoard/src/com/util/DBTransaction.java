package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBTransaction {


	public static Connection getConnection()
	{ 
		Connection conn = null;
	try 
	{
		Class.forName("oracle.jdbc.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@172.25.192.82:1521:javaaodb", "HJA40ORAUSER3D", "tcshyd");
		return conn;

	} 
	catch (ClassNotFoundException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return conn;
	}



	public static void close(Connection conn)
	{

		try 
		{ 
			if(conn != null && conn.isClosed()==false)
			conn.close();
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}


}
